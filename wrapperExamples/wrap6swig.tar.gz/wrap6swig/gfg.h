
long long int fact(long long int n); 
int my_mod(int n, int m); 

